Program has these known errors:

Jump function may be roughly 4-8 off from target address with larger files

Continuous La declarations sometimes cause strange malfunctions within array, such as an occasional repeated 'ori'

BNE has been tested to best of my ability, however, unknown if there are errors on larger files

* All instructions function, however, some with varying degrees when input sizes are increased, ie. First test is succcessful *
